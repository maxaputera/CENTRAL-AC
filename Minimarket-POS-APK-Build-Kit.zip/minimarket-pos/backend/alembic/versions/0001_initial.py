"""initial POS schema"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    op.create_table("users", sa.Column("id", sa.BigInteger(), primary_key=True), sa.Column("username", sa.String(60), nullable=False, unique=True), sa.Column("password_hash", sa.Text(), nullable=False), sa.Column("role", sa.String(20), nullable=False), sa.Column("active", sa.Boolean(), nullable=False), sa.CheckConstraint("role IN ('admin','cashier')", name="ck_users_role"))
    op.create_index("ix_users_username", "users", ["username"], unique=False)
    op.create_table("registers", sa.Column("id", sa.BigInteger(), primary_key=True), sa.Column("register_code", sa.String(30), nullable=False, unique=True), sa.Column("active", sa.Boolean(), nullable=False))
    op.create_index("ix_registers_register_code", "registers", ["register_code"], unique=False)
    op.create_table("products", sa.Column("id", sa.BigInteger(), primary_key=True), sa.Column("barcode", sa.String(100), nullable=False, unique=True), sa.Column("name", sa.String(200), nullable=False), sa.Column("price", sa.BigInteger(), nullable=False), sa.Column("active", sa.Boolean(), nullable=False), sa.CheckConstraint("price >= 0", name="ck_products_price_nonnegative"))
    op.create_index("ix_products_barcode", "products", ["barcode"], unique=False)
    op.create_table("inventory", sa.Column("product_id", sa.BigInteger(), sa.ForeignKey("products.id"), primary_key=True), sa.Column("quantity", sa.Integer(), nullable=False), sa.CheckConstraint("quantity >= 0", name="ck_inventory_quantity_nonnegative"))
    op.create_table("sales", sa.Column("id", sa.BigInteger(), primary_key=True), sa.Column("transaction_code", postgresql.UUID(as_uuid=True), nullable=False, unique=True), sa.Column("idempotency_key", sa.String(100), nullable=False, unique=True), sa.Column("cashier_id", sa.BigInteger(), sa.ForeignKey("users.id"), nullable=False), sa.Column("register_id", sa.BigInteger(), sa.ForeignKey("registers.id"), nullable=False), sa.Column("total", sa.BigInteger(), nullable=False), sa.Column("status", sa.String(20), nullable=False), sa.Column("created_at", sa.DateTime(timezone=True), nullable=False), sa.CheckConstraint("total >= 0", name="ck_sales_total_nonnegative"), sa.CheckConstraint("status IN ('pending','paid','cancelled')", name="ck_sales_status"))
    op.create_index("ix_sales_idempotency_key", "sales", ["idempotency_key"], unique=False)
    op.create_table("sale_items", sa.Column("id", sa.BigInteger(), primary_key=True), sa.Column("sale_id", sa.BigInteger(), sa.ForeignKey("sales.id", ondelete="CASCADE"), nullable=False), sa.Column("product_id", sa.BigInteger(), sa.ForeignKey("products.id"), nullable=False), sa.Column("product_name", sa.String(200), nullable=False), sa.Column("quantity", sa.Integer(), nullable=False), sa.Column("unit_price", sa.BigInteger(), nullable=False), sa.Column("subtotal", sa.BigInteger(), nullable=False), sa.CheckConstraint("quantity > 0", name="ck_sale_items_quantity_positive"), sa.CheckConstraint("unit_price >= 0 AND subtotal >= 0", name="ck_sale_items_amount_nonnegative"))
    op.create_index("ix_sale_items_sale_id", "sale_items", ["sale_id"], unique=False)
    op.create_table("payments", sa.Column("id", sa.BigInteger(), primary_key=True), sa.Column("sale_id", sa.BigInteger(), sa.ForeignKey("sales.id", ondelete="CASCADE"), nullable=False), sa.Column("method", sa.String(20), nullable=False), sa.Column("amount", sa.BigInteger(), nullable=False), sa.Column("status", sa.String(20), nullable=False), sa.Column("provider_reference", sa.String(200)), sa.CheckConstraint("method IN ('cash','qris')", name="ck_payments_method"), sa.CheckConstraint("status IN ('pending','paid','failed')", name="ck_payments_status"), sa.CheckConstraint("amount >= 0", name="ck_payments_amount_nonnegative"))
    op.create_index("ix_payments_sale_id", "payments", ["sale_id"], unique=False)
    op.create_table("stock_movements", sa.Column("id", sa.BigInteger(), primary_key=True), sa.Column("product_id", sa.BigInteger(), sa.ForeignKey("products.id"), nullable=False), sa.Column("sale_id", sa.BigInteger(), sa.ForeignKey("sales.id")), sa.Column("quantity_delta", sa.Integer(), nullable=False), sa.Column("reason", sa.String(40), nullable=False), sa.Column("created_at", sa.DateTime(timezone=True), nullable=False))
    op.create_index("ix_stock_movements_product_id", "stock_movements", ["product_id"], unique=False)

def downgrade():
    op.drop_table("stock_movements")
    op.drop_index("ix_payments_sale_id", table_name="payments")
    op.drop_table("payments")
    op.drop_index("ix_sale_items_sale_id", table_name="sale_items")
    op.drop_table("sale_items")
    op.drop_index("ix_sales_idempotency_key", table_name="sales")
    op.drop_table("sales")
    op.drop_table("inventory")
    op.drop_index("ix_products_barcode", table_name="products")
    op.drop_table("products")
    op.drop_index("ix_registers_register_code", table_name="registers")
    op.drop_table("registers")
    op.drop_index("ix_users_username", table_name="users")
    op.drop_table("users")
