from pydantic import BaseModel, Field, ConfigDict
from typing import Literal
from uuid import UUID
from datetime import datetime

class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=60)
    password: str = Field(min_length=1, max_length=200)

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    username: str
    role: str

class ProductOut(BaseModel):
    id: int
    barcode: str
    name: str
    price: int
    quantity: int = 0
    model_config = ConfigDict(from_attributes=True)

class SaleItemIn(BaseModel):
    barcode: str = Field(min_length=1, max_length=100)
    quantity: int = Field(gt=0, le=1000)

class SaleCreate(BaseModel):
    register_code: str = Field(min_length=1, max_length=30)
    payment_method: Literal["cash"] = "cash"
    cash_received: int = Field(ge=0)
    items: list[SaleItemIn] = Field(min_length=1, max_length=100)

class SaleItemOut(BaseModel):
    product_id: int
    product_name: str
    quantity: int
    unit_price: int
    subtotal: int

class SaleOut(BaseModel):
    id: int
    transaction_code: UUID
    total: int
    status: str
    change: int
    created_at: datetime
    items: list[SaleItemOut]
