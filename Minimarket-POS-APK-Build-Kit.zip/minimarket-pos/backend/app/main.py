import uuid
from datetime import datetime, timezone
from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy import select, func
from sqlalchemy.orm import Session, selectinload
from sqlalchemy.exc import IntegrityError
import jwt
from jwt import InvalidTokenError
from app.database import Base, engine, get_db
from app.config import settings
from app.models import User, Register, Product, Inventory, Sale, SaleItem, Payment, StockMovement
from app.schemas import LoginRequest, TokenResponse, ProductOut, SaleCreate, SaleOut, SaleItemOut
from app.security import verify_password, create_access_token

app = FastAPI(title="Minimarket POS API", version="0.1.0", description="MVP API untuk POS Android minimarket")
bearer = HTTPBearer(auto_error=False)

@app.on_event("startup")
def startup():
    # Untuk development/demo saja. Production sebaiknya menjalankan `alembic upgrade head`.
    Base.metadata.create_all(bind=engine)

@app.get("/health")
def health():
    return {"status": "ok", "service": "minimarket-pos-api"}

def current_user(credentials: HTTPAuthorizationCredentials | None = Depends(bearer), db: Session = Depends(get_db)) -> User:
    if not credentials:
        raise HTTPException(status_code=401, detail="Token diperlukan")
    try:
        payload = jwt.decode(credentials.credentials, settings.secret_key, algorithms=["HS256"])
        user_id = int(payload["sub"])
    except (InvalidTokenError, KeyError, ValueError):
        raise HTTPException(status_code=401, detail="Token tidak valid atau kedaluwarsa")
    user = db.get(User, user_id)
    if not user or not user.active:
        raise HTTPException(status_code=401, detail="Pengguna tidak aktif")
    return user

@app.post("/auth/login", response_model=TokenResponse)
def login(body: LoginRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.username == body.username))
    if not user or not user.active or not verify_password(body.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Username atau password salah")
    return TokenResponse(access_token=create_access_token(user.id, user.username, user.role), expires_in=settings.access_token_minutes * 60, username=user.username, role=user.role)

@app.get("/products", response_model=list[ProductOut])
def list_products(q: str | None = None, db: Session = Depends(get_db), user: User = Depends(current_user)):
    stmt = select(Product, Inventory.quantity).outerjoin(Inventory, Inventory.product_id == Product.id).where(Product.active.is_(True)).order_by(Product.name).limit(200)
    if q:
        stmt = stmt.where((Product.name.ilike(f"%{q}%")) | (Product.barcode == q))
    rows = db.execute(stmt).all()
    return [ProductOut(id=p.id, barcode=p.barcode, name=p.name, price=p.price, quantity=qty or 0) for p, qty in rows]

@app.get("/products/barcode/{barcode}", response_model=ProductOut)
def get_product_by_barcode(barcode: str, db: Session = Depends(get_db), user: User = Depends(current_user)):
    row = db.execute(select(Product, Inventory.quantity).outerjoin(Inventory, Inventory.product_id == Product.id).where(Product.barcode == barcode, Product.active.is_(True))).first()
    if not row:
        raise HTTPException(status_code=404, detail="Produk tidak ditemukan")
    p, qty = row
    return ProductOut(id=p.id, barcode=p.barcode, name=p.name, price=p.price, quantity=qty or 0)

@app.post("/sales", response_model=SaleOut, status_code=201)
def create_sale(body: SaleCreate, idempotency_key: str = Header(alias="Idempotency-Key", min_length=8, max_length=100), db: Session = Depends(get_db), user: User = Depends(current_user)):
    existing = db.scalar(select(Sale).options(selectinload(Sale.items)).where(Sale.idempotency_key == idempotency_key))
    if existing:
        return SaleOut(id=existing.id, transaction_code=existing.transaction_code, total=existing.total, status=existing.status, change=max(0, body.cash_received-existing.total), created_at=existing.created_at, items=[SaleItemOut(product_id=i.product_id, product_name=i.product_name, quantity=i.quantity, unit_price=i.unit_price, subtotal=i.subtotal) for i in existing.items])
    register = db.scalar(select(Register).where(Register.register_code == body.register_code, Register.active.is_(True)))
    if not register:
        raise HTTPException(status_code=400, detail="Kode kasir/perangkat tidak dikenal")
    # Gabungkan barcode yang sama supaya stok divalidasi konsisten.
    requested: dict[str, int] = {}
    for item in body.items:
        requested[item.barcode] = requested.get(item.barcode, 0) + item.quantity
    try:
        products = {}
        for barcode in sorted(requested):
            p = db.scalar(select(Product).where(Product.barcode == barcode, Product.active.is_(True)))
            if not p:
                raise HTTPException(status_code=400, detail=f"Barcode tidak dikenal: {barcode}")
            inv = db.scalar(select(Inventory).where(Inventory.product_id == p.id).with_for_update())
            if not inv or inv.quantity < requested[barcode]:
                raise HTTPException(status_code=409, detail=f"Stok tidak cukup untuk {p.name}")
            products[barcode] = (p, inv)
        lines = []
        total = 0
        for barcode, qty in requested.items():
            p, inv = products[barcode]
            subtotal = p.price * qty
            total += subtotal
            lines.append((p, inv, qty, subtotal))
        if body.cash_received < total:
            raise HTTPException(status_code=400, detail="Uang tunai kurang dari total belanja")
        sale = Sale(transaction_code=uuid.uuid4(), idempotency_key=idempotency_key, cashier_id=user.id, register_id=register.id, total=total, status="paid", created_at=datetime.now(timezone.utc))
        db.add(sale)
        db.flush()
        for p, inv, qty, subtotal in lines:
            inv.quantity -= qty
            sale.items.append(SaleItem(product_id=p.id, product_name=p.name, quantity=qty, unit_price=p.price, subtotal=subtotal))
            db.add(StockMovement(product_id=p.id, sale_id=sale.id, quantity_delta=-qty, reason="sale"))
        db.add(Payment(sale_id=sale.id, method="cash", amount=total, status="paid"))
        db.commit()
        db.refresh(sale)
        return SaleOut(id=sale.id, transaction_code=sale.transaction_code, total=total, status=sale.status, change=body.cash_received-total, created_at=sale.created_at, items=[SaleItemOut(product_id=i.product_id, product_name=i.product_name, quantity=i.quantity, unit_price=i.unit_price, subtotal=i.subtotal) for i in sale.items])
    except HTTPException:
        db.rollback()
        raise
    except IntegrityError:
        db.rollback()
        # Kemungkinan request duplikat bersamaan; klien dapat mengulang request dengan key yang sama.
        existing = db.scalar(select(Sale).options(selectinload(Sale.items)).where(Sale.idempotency_key == idempotency_key))
        if existing:
            return SaleOut(id=existing.id, transaction_code=existing.transaction_code, total=existing.total, status=existing.status, change=max(0, body.cash_received-existing.total), created_at=existing.created_at, items=[SaleItemOut(product_id=i.product_id, product_name=i.product_name, quantity=i.quantity, unit_price=i.unit_price, subtotal=i.subtotal) for i in existing.items])
        raise HTTPException(status_code=409, detail="Konflik transaksi; silakan coba ulang dengan key yang sama")

@app.get("/sales/{sale_id}", response_model=SaleOut)
def get_sale(sale_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    sale = db.scalar(select(Sale).options(selectinload(Sale.items)).where(Sale.id == sale_id))
    if not sale:
        raise HTTPException(status_code=404, detail="Transaksi tidak ditemukan")
    return SaleOut(id=sale.id, transaction_code=sale.transaction_code, total=sale.total, status=sale.status, change=0, created_at=sale.created_at, items=[SaleItemOut(product_id=i.product_id, product_name=i.product_name, quantity=i.quantity, unit_price=i.unit_price, subtotal=i.subtotal) for i in sale.items])

@app.get("/reports/daily")
def daily_report(db: Session = Depends(get_db), user: User = Depends(current_user)):
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Khusus administrator")
    today = datetime.now(timezone.utc).date()
    start = datetime.combine(today, datetime.min.time(), tzinfo=timezone.utc)
    end = datetime.combine(today, datetime.max.time(), tzinfo=timezone.utc)
    count, revenue = db.query(func.count(Sale.id), func.coalesce(func.sum(Sale.total), 0)).filter(Sale.status == "paid", Sale.created_at >= start, Sale.created_at <= end).one()
    return {"date_utc": str(today), "transactions": count, "revenue_idr": int(revenue)}
