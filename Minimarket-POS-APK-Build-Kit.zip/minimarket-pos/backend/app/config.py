from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "postgresql+psycopg://pos:change_this_db_password@localhost:5432/posdb"
    secret_key: str = "dev-only-change-me"
    access_token_minutes: int = 30
    register_code_default: str = "KASIR-01"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
