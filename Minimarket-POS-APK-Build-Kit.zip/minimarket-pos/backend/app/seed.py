from sqlalchemy import select
from app.database import Base, engine, SessionLocal
from app.models import User, Register, Product, Inventory
from app.security import hash_password

Base.metadata.create_all(bind=engine)
with SessionLocal() as db:
    if not db.scalar(select(User).where(User.username == "admin")):
        db.add(User(username="admin", password_hash=hash_password("ChangeMe123!"), role="admin", active=True))
    if not db.scalar(select(Register).where(Register.register_code == "KASIR-01")):
        db.add(Register(register_code="KASIR-01", active=True))
    if not db.scalar(select(Product).where(Product.barcode == "8991002100018")):
        p = Product(barcode="8991002100018", name="Contoh Air Mineral 600ml", price=4000, active=True)
        db.add(p)
        db.flush()
        db.add(Inventory(product_id=p.id, quantity=100))
    db.commit()
print("Seed selesai. Login demo: admin / ChangeMe123! — ganti sebelum penggunaan nyata.")
