# Minimarket POS — MVP Android + FastAPI + PostgreSQL

Starter project untuk POS minimarket dengan banyak perangkat Android, API terpusat, dan rancangan hybrid lokal/cloud.

## Status MVP
- Backend: login JWT, produk/barcode, transaksi tunai, pengurangan stok atomik, idempotensi transaksi, laporan harian sederhana.
- Database: PostgreSQL, SQLAlchemy, Alembic migration.
- Android: Kotlin + Jetpack Compose, layar kasir sederhana, input barcode manual atau scanner Bluetooth/USB mode keyboard-wedge, keranjang dan checkout tunai.
- Belum siap produksi: pembayaran QRIS nyata, pencetakan Bluetooth, sinkronisasi cloud-lokal, refresh token, manajemen stok UI, dan hardening operasional perlu tahap lanjutan.

## 1. Jalankan backend
Persyaratan: Docker + Docker Compose.

```bash
cd backend
cp .env.example .env
# Ganti SECRET_KEY sebelum penggunaan selain pengembangan.
docker compose up --build
```

API: http://localhost:8000  
Dokumentasi interaktif: http://localhost:8000/docs  
Health check: http://localhost:8000/health

Aplikasi membuat tabel saat startup untuk memudahkan demo; migration Alembic juga disediakan dan dapat dipakai untuk pengelolaan skema yang eksplisit.

### Akun demo
Setelah server hidup, jalankan:

```bash
docker compose exec api python -m app.seed
```

Login: `admin` / `ChangeMe123!` (ubah setelah login / sebelum penggunaan nyata).

### Contoh alur API
1. `POST /auth/login` dengan `{"username":"admin","password":"ChangeMe123!"}`.
2. Salin token `access_token`, pakai header `Authorization: Bearer <token>`.
3. `GET /products/barcode/8991002100018`.
4. `POST /sales` dengan header `Idempotency-Key: <UUID>` dan body:

```json
{
  "register_code": "KASIR-01",
  "payment_method": "cash",
  "cash_received": 20000,
  "items": [{"barcode": "8991002100018", "quantity": 2}]
}
```

## 2. Android
Buka folder `android/` di Android Studio versi baru. Starter memakai Kotlin, Compose, dan Retrofit. Atur `BASE_URL` di `PosApi.kt`:
- Emulator Android ke backend di komputer host: `http://10.0.2.2:8000/`
- Perangkat fisik di Wi-Fi lokal: `http://IP-KOMPUTER-SERVER:8000/`

Untuk uji di perangkat fisik, server harus mendengarkan pada jaringan lokal dan firewall mengizinkan port 8000. HTTP cleartext diizinkan hanya untuk pengembangan. Untuk produksi, gunakan HTTPS.

Scanner yang berfungsi sebagai keyboard biasanya mengetik barcode ke kolom input lalu mengirim Enter. Dukungan kamera dan SDK scanner khusus belum dimasukkan ke MVP.

## 3. Hybrid lokal + cloud (arsitektur target)
Rekomendasi tahap awal: server lokal di toko adalah sumber kebenaran transaksi ketika internet putus; cloud menerima replikasi/event untuk laporan dan backup. Jangan menjalankan dua database writable yang independen tanpa aturan konflik. Gunakan ID transaksi UUID, outbox/event log, checkpoint sinkronisasi, retry idempoten, dan rekonsiliasi konflik. Modul sinkronisasi belum diimplementasikan di starter ini.

## 4. Keamanan dan operasional
- Ganti `SECRET_KEY`, kredensial demo, dan password database.
- Jangan buka PostgreSQL ke internet; hanya API yang boleh diakses klien.
- Produksi memerlukan HTTPS, backup teruji, logging terstruktur, monitoring, rate limiting, manajemen secret, serta prosedur void/refund dan audit.
- Endpoint penjualan memakai transaksi database dan row lock untuk stok, serta `Idempotency-Key` untuk mencegah transaksi ganda saat retry.
- Uji dengan stok nol, dua kasir bersamaan, request duplikat, dan putus jaringan sebelum dipakai di toko.

Lihat `docs/ARCHITECTURE.md` untuk rincian.
