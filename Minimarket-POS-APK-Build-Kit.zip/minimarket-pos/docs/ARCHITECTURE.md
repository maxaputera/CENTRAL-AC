# Arsitektur POS Hybrid

## Komponen
- Android POS (Kotlin/Compose): login, scan/input barcode, cart, checkout, receipt view.
- Local store server: FastAPI + PostgreSQL di LAN; menangani transaksi dan stok saat internet mati.
- Cloud service: menerima event/outbox dari server toko, menyimpan backup dan data laporan lintas cabang.
- Printer: Bluetooth ESC/POS melalui Android; integrasi lanjutan perlu izin Bluetooth Android versi target dan uji model printer.
- QRIS: integrasi API provider/acquirer resmi; status sukses wajib berasal dari callback/webhook terverifikasi atau status inquiry, bukan dari screenshot atau input kasir.

## Prinsip data
1. Server toko adalah sumber kebenaran transaksi lokal.
2. Semua transaksi memiliki UUID global dan idempotency key.
3. Penjualan, sale_items, payment, dan inventory update harus satu transaksi database.
4. Snapshot nama/harga produk disimpan pada sale_items agar histori tidak berubah ketika master produk diedit.
5. Void/refund dibuat sebagai transaksi pembalik/audit, bukan menghapus penjualan.
6. Cloud sync menggunakan transactional outbox: event ditulis bersama transaksi, lalu worker mengirim ulang dengan idempotensi. Conflict resolution dan sinkronisasi belum diimplementasikan pada MVP ini.

## Deployment hybrid yang disarankan
- LAN toko: Android → HTTPS lokal (atau VPN/private network) → API toko → PostgreSQL toko.
- Internet tersedia: worker toko mengirim outbox ke cloud API.
- Internet mati: transaksi lokal tetap bisa dilakukan jika LAN dan server toko aktif.
- Server toko mati: MVP belum memiliki mode offline penuh antar-perangkat; diperlukan antrean lokal per perangkat dan rekonsiliasi untuk tahap selanjutnya.

## Keamanan
Gunakan TLS, secrets dari environment/secret manager, password hashing Argon2/bcrypt, akses berbasis peran, audit log, backup terenkripsi, dan pembatasan akses jaringan. JWT MVP ini hanya cocok untuk starter; token expiry pendek dan refresh-token rotation perlu ditambahkan sebelum produksi.
