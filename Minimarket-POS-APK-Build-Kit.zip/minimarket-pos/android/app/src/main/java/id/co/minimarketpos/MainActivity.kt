package id.co.minimarketpos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.util.UUID

private data class CartLine(val product: ProductDto, val quantity: Int)
private fun rupiah(value: Long) = "Rp " + String.format("%,d", value).replace(',', '.')

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { PosScreen() } }
    }
}

@Composable
private fun PosScreen() {
    val api = remember { PosApi.instance }
    val scope = rememberCoroutineScope()
    var username by remember { mutableStateOf("admin") }
    var password by remember { mutableStateOf("ChangeMe123!") }
    var token by remember { mutableStateOf<String?>(null) }
    var role by remember { mutableStateOf("") }
    var barcode by remember { mutableStateOf("") }
    var cash by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Masuk dengan akun demo setelah menjalankan backend dan seed.") }
    var busy by remember { mutableStateOf(false) }
    var cart by remember { mutableStateOf(listOf<CartLine>()) }
    var lastSale by remember { mutableStateOf<SaleResponse?>(null) }
    var idempotencyKey by remember { mutableStateOf(UUID.randomUUID().toString()) }
    val total = cart.sumOf { it.product.price * it.quantity }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("MINIMARKET POS", style = MaterialTheme.typography.headlineSmall)
        if (token == null) {
            OutlinedTextField(username, { username = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(password, { password = it }, label = { Text("Password") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(enabled = !busy, onClick = {
                busy = true
                scope.launch {
                    try { val result = api.login(LoginRequest(username, password)); token = result.access_token; role = result.role; status = "Login berhasil: ${result.username} ($role)" }
                    catch (e: Exception) { status = "Login gagal: ${e.message ?: "periksa koneksi/server"}" }
                    finally { busy = false }
                }
            }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Memproses..." else "Login") }
        } else {
            Text("Kasir: $username · $role")
            OutlinedTextField(value = barcode, onValueChange = { barcode = it }, label = { Text("Scan / masukkan barcode") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            Button(enabled = !busy && barcode.isNotBlank(), onClick = {
                val code = barcode.trim(); barcode = ""; busy = true
                scope.launch {
                    try {
                        val p = api.productByBarcode("Bearer $token", code)
                        val old = cart.firstOrNull { it.product.id == p.id }
                        cart = if (old == null) cart + CartLine(p, 1) else cart.map { if (it.product.id == p.id) it.copy(quantity = it.quantity + 1) else it }
                        idempotencyKey = UUID.randomUUID().toString()
                        status = "Ditambahkan: ${p.name}"
                    } catch (e: Exception) { status = "Produk gagal dicari: ${e.message ?: "barcode tidak ditemukan"}" }
                    finally { busy = false }
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("Tambah produk") }
            Text("Keranjang", style = MaterialTheme.typography.titleMedium)
            LazyColumn(Modifier.weight(1f, fill = false)) {
                items(cart, key = { it.product.id }) { line ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) { Text(line.product.name); Text("${line.quantity} × ${rupiah(line.product.price)}", style = MaterialTheme.typography.bodySmall) }
                        Text(rupiah(line.product.price * line.quantity))
                        TextButton(onClick = { cart = cart.filterNot { it.product.id == line.product.id }; idempotencyKey = UUID.randomUUID().toString() }) { Text("Hapus") }
                    }
                }
            }
            HorizontalDivider()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("TOTAL", style = MaterialTheme.typography.titleLarge); Text(rupiah(total), style = MaterialTheme.typography.titleLarge) }
            OutlinedTextField(value = cash, onValueChange = { cash = it.filter(Char::isDigit) }, label = { Text("Uang tunai diterima (rupiah)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(enabled = !busy && cart.isNotEmpty() && (cash.toLongOrNull() ?: 0L) >= total, onClick = {
                busy = true
                scope.launch {
                    try {
                        val req = SaleRequest("KASIR-01", "cash", cash.toLongOrNull() ?: 0L, cart.map { SaleLineRequest(it.product.barcode, it.quantity) })
                        val sale = api.createSale("Bearer $token", idempotencyKey, req)
                        lastSale = sale; cart = emptyList(); cash = ""; idempotencyKey = UUID.randomUUID().toString(); status = "Transaksi #${sale.id} berhasil. Kembalian ${rupiah(sale.change)}"
                    } catch (e: Exception) { status = "Transaksi gagal: ${e.message ?: "periksa koneksi"}" }
                    finally { busy = false }
                }
            }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Memproses..." else "Bayar tunai") }
            TextButton(onClick = { token = null; cart = emptyList(); status = "Anda telah keluar." }) { Text("Keluar") }
            lastSale?.let { sale ->
                Text("Struk digital · #${sale.id}", style = MaterialTheme.typography.titleMedium)
                sale.items.forEach { Text("${it.quantity} × ${it.product_name} — ${rupiah(it.subtotal)}") }
                Text("Total: ${rupiah(sale.total)} · ${sale.status}")
            }
        }
        Text(status, style = MaterialTheme.typography.bodySmall)
        Text("MVP pengembangan: gunakan jaringan tepercaya; HTTPS dan penyimpanan token aman perlu ditambahkan sebelum produksi.", style = MaterialTheme.typography.labelSmall)
    }
}
