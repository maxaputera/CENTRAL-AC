package id.co.minimarketpos

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path

data class LoginRequest(val username: String, val password: String)
data class TokenResponse(val access_token: String, val token_type: String, val expires_in: Int, val username: String, val role: String)
data class ProductDto(val id: Long, val barcode: String, val name: String, val price: Long, val quantity: Int = 0)
data class SaleLineRequest(val barcode: String, val quantity: Int)
data class SaleRequest(val register_code: String, val payment_method: String = "cash", val cash_received: Long, val items: List<SaleLineRequest>)
data class SaleLineDto(val product_id: Long, val product_name: String, val quantity: Int, val unit_price: Long, val subtotal: Long)
data class SaleResponse(val id: Long, val transaction_code: String, val total: Long, val status: String, val change: Long, val created_at: String, val items: List<SaleLineDto>)

interface PosApi {
    @POST("auth/login") suspend fun login(@Body body: LoginRequest): TokenResponse
    @GET("products/barcode/{barcode}") suspend fun productByBarcode(@Header("Authorization") token: String, @Path("barcode") barcode: String): ProductDto
    @POST("sales") suspend fun createSale(@Header("Authorization") token: String, @Header("Idempotency-Key") key: String, @Body body: SaleRequest): SaleResponse
    companion object {
        // Emulator Android -> host computer. Untuk perangkat fisik ganti dengan IP server lokal.
        private const val BASE_URL = "http://10.0.2.2:8000/"
        val instance: PosApi by lazy { Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create()).build().create(PosApi::class.java) }
    }
}
