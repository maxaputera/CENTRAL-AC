# Membuat APK Minimarket POS

## Opsi A — Android Studio
1. Ekstrak ZIP proyek.
2. Buka folder `android/` dengan Android Studio versi baru.
3. Tunggu Gradle Sync selesai dan izinkan Android Studio memasang Android SDK yang diminta.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug biasanya muncul di `android/app/build/outputs/apk/debug/app-debug.apk`.

## Opsi B — Build otomatis di GitHub Actions
Workflow `.github/workflows/build-android.yml` disertakan.
1. Unggah isi folder proyek ke repository GitHub milik sendiri.
2. Buka tab **Actions**, pilih **Build Android APK**, lalu **Run workflow**.
3. Setelah job sukses, buka hasil run dan unduh artifact `minimarket-pos-debug-apk`.
4. Ekstrak artifact untuk memperoleh `app-debug.apk`.

Workflow ini menghasilkan **debug APK** untuk pengujian, bukan APK release bertanda tangan untuk distribusi produksi.

## Catatan
- Kode ini adalah MVP pengembangan. Belum semua fitur produksi selesai; QRIS sungguhan, printer Bluetooth, dan sinkronisasi lokal/cloud belum diimplementasikan.
- Aplikasi perlu dikonfigurasi agar `BASE_URL` di `android/app/src/main/java/id/co/minimarketpos/PosApi.kt` menunjuk ke server API yang dapat dijangkau perangkat.
- Jangan gunakan akun demo atau konfigurasi rahasia bawaan untuk operasional toko.
